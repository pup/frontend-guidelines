const { Subject, mergeMap, of, tap } = require('./rxjs');

let count = 0;

const wait = (data) => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve(data);
    }, 1000);
  });
};

if (!global.pdfSubject) {
  global.pdfSubject = new Subject();
  global.pdfSubject
    .pipe(
      mergeMap(async (data) => {
        const result = await wait(data);
        return result;
      }, 2)
    )
    .subscribe((task) => {
      console.log(`>>> 剩余任务数量：${--count} 任务完成：${task}`);
    });
}

const printPDF = (reportId) => {
  // setTimeout(() => {
  //   console.log(`启动任务：${reportId} 当前任务数量：${++count}`);
  //   global.pdfSubject.next(reportId);
  // }, reportId);
  console.log(`当前任务数量：${++count}  启动任务：${reportId}`);
  global.pdfSubject.next(reportId);
};

module.exports = { printPDF };
