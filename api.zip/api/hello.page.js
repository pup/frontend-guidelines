// Next.js API route support: https://nextjs.org/docs/api-routes/introduction

const { printPDF } = require('./pdf-helper');

const random = (min, max) => {
  return Math.floor(Math.random() * (max - min))
}

export default function handler(req, res) {
  printPDF(random(0, 1000 * 1));
  printPDF(random(0, 1000 * 2));
  printPDF(random(0, 1000 * 3));
  printPDF(random(0, 1000 * 4));
  printPDF(random(0, 1000 * 5));
  printPDF(random(0, 1000 * 6));
  printPDF(random(0, 1000 * 7));
  printPDF(random(0, 1000 * 8));
  printPDF(random(0, 1000 * 9));
  printPDF(random(0, 1000 * 10));
  res.status(200).json({ name: 'John Doe' });
}
